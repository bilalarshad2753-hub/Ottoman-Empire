import osmanI from "@/assets/sultans/01-osman-i.jpg.asset.json";
import orhan from "@/assets/sultans/02-orhan.jpg.asset.json";
import muradI from "@/assets/sultans/03-murad-i.jpg.asset.json";
import bayezidI from "@/assets/sultans/04-bayezid-i.jpg.asset.json";
import mehmedI from "@/assets/sultans/05-mehmed-i.jpg.asset.json";
import muradII from "@/assets/sultans/06-murad-ii.jpg.asset.json";
import mehmedII from "@/assets/sultans/07-mehmed-ii.jpg.asset.json";
import bayezidII from "@/assets/sultans/08-bayezid-ii.jpg.asset.json";
import selimI from "@/assets/sultans/09-selim-i.jpg.asset.json";
import suleimanI from "@/assets/sultans/10-suleiman-i.jpg.asset.json";
import selimII from "@/assets/sultans/11-selim-ii.jpg.asset.json";
import muradIII from "@/assets/sultans/12-murad-iii.jpg.asset.json";
import mehmedIII from "@/assets/sultans/13-mehmed-iii.jpg.asset.json";
import ahmedI from "@/assets/sultans/14-ahmed-i.jpg.asset.json";
import mustafaI from "@/assets/sultans/15-mustafa-i.jpg.asset.json";
import osmanII from "@/assets/sultans/16-osman-ii.jpg.asset.json";
import muradIV from "@/assets/sultans/17-murad-iv.jpg.asset.json";
import ibrahim from "@/assets/sultans/18-ibrahim.jpg.asset.json";
import mehmedIV from "@/assets/sultans/19-mehmed-iv.jpg.asset.json";
import suleimanII from "@/assets/sultans/20-suleiman-ii.jpg.asset.json";
import ahmedII from "@/assets/sultans/21-ahmed-ii.jpg.asset.json";
import mustafaII from "@/assets/sultans/22-mustafa-ii.jpg.asset.json";
import ahmedIII from "@/assets/sultans/23-ahmed-iii.jpg.asset.json";
import mahmudI from "@/assets/sultans/24-mahmud-i.jpg.asset.json";
import osmanIII from "@/assets/sultans/25-osman-iii.jpg.asset.json";
import mustafaIII from "@/assets/sultans/26-mustafa-iii.jpg.asset.json";
import abdulhamidI from "@/assets/sultans/27-abdulhamid-i.jpg.asset.json";
import selimIII from "@/assets/sultans/28-selim-iii.jpg.asset.json";
import mustafaIV from "@/assets/sultans/29-mustafa-iv.jpg.asset.json";
import mahmudII from "@/assets/sultans/30-mahmud-ii.jpg.asset.json";
import abdulmejidI from "@/assets/sultans/31-abdulmejid-i.jpg.asset.json";
import abdulaziz from "@/assets/sultans/32-abdulaziz.jpg.asset.json";
import muradV from "@/assets/sultans/33-murad-v.jpg.asset.json";
import abdulhamidII from "@/assets/sultans/34-abdulhamid-ii.jpg.asset.json";
import mehmedV from "@/assets/sultans/35-mehmed-v.jpg.asset.json";
import mehmedVI from "@/assets/sultans/36-mehmed-vi.jpg.asset.json";

const portraitAssets = [
  osmanI, orhan, muradI, bayezidI, mehmedI, muradII, mehmedII, bayezidII,
  selimI, suleimanI, selimII, muradIII, mehmedIII, ahmedI, mustafaI,
  osmanII, muradIV, ibrahim, mehmedIV, suleimanII, ahmedII, mustafaII,
  ahmedIII, mahmudI, osmanIII, mustafaIII, abdulhamidI, selimIII,
  mustafaIV, mahmudII, abdulmejidI, abdulaziz, muradV, abdulhamidII,
  mehmedV, mehmedVI,
];

export const sultanPortraits = portraitAssets.map((asset) => asset.url);