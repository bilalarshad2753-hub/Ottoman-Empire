# Sultan portrait sources

All 36 portraits were downloaded on 27 September 2026 from the Turkish Historical Society (Türk Tarih Kurumu), not Wikipedia or Wikimedia.

- Collection page: https://ttk.gov.tr/osmanli-padisahlari/
- Original files: the numbered `a1_Osman_Gazi.gif` through `a36_Mehmed_Vahdettin.gif` images hosted on `ttk.gov.tr`
- Stored copies: each adjacent `.asset.json` file points to a permanent project-hosted JPEG copy.